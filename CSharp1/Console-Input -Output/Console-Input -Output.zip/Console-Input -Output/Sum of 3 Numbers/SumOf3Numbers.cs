﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sum_of_3_Numbers
{
    class SumOf3Numbers
    {
        static void Main(string[] args)
        {
         Console.WriteLine("a=");
         int a = int.Parse(Console.ReadLine());

         Console.WriteLine("b=");
         int b = int.Parse(Console.ReadLine());

         Console.WriteLine("c=");
         int c = int.Parse(Console.ReadLine());

         int sum = a + b + c;

         Console.WriteLine( sum );



             

        }
    }
}
