﻿using System;

namespace DateTimeNow
{
    class DateTimeNow
    {
        static void Main()
        {
            Console.WriteLine(DateTime.Now);
        }
    }
}
