﻿using System;

namespace PrintMyName
{
    class PrintMyName
    {
        static void Main()
        {
            Console.WriteLine( "Gyokay" );
        }
    }
}
