﻿using System;

namespace FirstAndLastName
{
    class PrintTheNumbers
    {
        static void Main()
        {
            Console.WriteLine("1{0}101{0}1001", Environment.NewLine);
        }
    }
}
