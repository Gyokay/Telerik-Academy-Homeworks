﻿using System;

namespace HelloCSharp
{
    class HelloCSharp
    {
        static void Main()
        {
            Console.WriteLine( "Hello, C#!" );
        }
    }
}
