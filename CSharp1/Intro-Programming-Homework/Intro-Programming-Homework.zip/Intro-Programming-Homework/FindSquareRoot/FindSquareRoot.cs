﻿using System;

namespace FindSquareRoot
{
    class FindSquareRoot
    {
        static void Main()
        {
            int number = 12345;
            Console.WriteLine(Math.Sqrt(number));
        }
    }
}
