﻿using System;

namespace FirstAndLastName
{
    class FistAndLastName
    {
        static void Main()
        {
            Console.WriteLine("Gyokay{0}Ahmed", Environment.NewLine);
        }
    }
}
